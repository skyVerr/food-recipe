import { Component, OnInit } from '@angular/core';
import { Recipe } from 'src/app/models/recipe';
import { DataService } from 'src/app/services/data.service';
import { async, reject } from 'q';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  recipes: Recipe[];
  search: any;
  searchArray;
  userInput;
  predectiveResult;

  constructor(
    private dataService: DataService
  ) { 
    this.userInput = new Array();
  }

  ngOnInit() {

  }

  async onKeyUp(event){
    let data = {};

    this.predectiveResult = "";
    
    this.dataService.search(event.target.value)
      .subscribe(recipes=>{

        // recipes.forEach(recipe => {
        //   data[recipe.name] = recipe.image;
        // });

        // this.searchArray = [{data}];
        event.target.blur();
        event.target.focus();

        if(event.keyCode == 13){
          if(event.target.value.split(' ').length == 1){
            this.dataService.searchByTag(event.target.value)
              .subscribe(recipe2=>{
                if(recipe2.length >= 1){
                  this.recipes = recipe2;
                } else {
                  this.recipes = recipes;
                }
              });
          } else {
            this.recipes = recipes;
          }
        }

      });

    if(event.target.value.length > 1){
      if(typeof this.userInput[event.target.value] =='undefined'){
          this.userInput[event.target.value] == 1
        } else {
            this.userInput[event.target.value]++;
        }
    }
          
    let basePredict = event.target.value;
    let prediction = new Array();

    do {
      prediction = await this.predict(basePredict);
      console.log(prediction);
      if(prediction.length==0) break;
      basePredict = prediction[Math.floor(Math.random()*prediction.length)].predictText;
      this.predectiveResult = basePredict;
    } while (await prediction.length != 0);

  } 

  predict(keyword):Promise<any>{
    return new Promise((resolve,reject)=>{
        
      let charCodes = this.getCharCodes();
      let prediction = new Array();
      let noOfCharChecked = 0;

      charCodes.forEach((charCode) => {
        let predictText = keyword+String.fromCharCode(charCode);
        
        this.dataService.numRows(predictText)
        .subscribe(data=>{
          if(data['count'] > 0){
            prediction.push({predictText, count: data['count']});
            }
            noOfCharChecked++;
            if(noOfCharChecked == 42){
              resolve(prediction);
            }
          });
      });
    });
  }



  getCharCodes(){
    //get all character codes in a-z and A-Z
    let charCode = 97;
    let charCodes = new Array();
    for  (let n = 0; n < 26; n++) {
      charCodes.push(charCode+n);
      //loop through capital letters
      if(n==25 && charCode!=65){ 
        charCode=65;
        n=-1;
      }

    }
    return charCodes;
  }
  

}
