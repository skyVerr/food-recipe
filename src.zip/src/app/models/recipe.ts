export interface Recipe {
    recipe_id: number;
    name: string;
    ingredients: string;
    preparation: string;
    image: string;
}